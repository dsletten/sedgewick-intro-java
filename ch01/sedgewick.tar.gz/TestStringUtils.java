/*
 */

import utils.StringUtils;

public class TestStringUtils
{
    public static void main( String[] args )
    {
        System.out.println( StringUtils.pluralize( 1, "dog" ) );
        System.out.println( StringUtils.pluralize( 2, "dog" ) );
        System.out.println( StringUtils.pluralize( 1, "penny", "pennies" ) );
        System.out.println( StringUtils.pluralize( 2, "woman", "women" ) );

        System.out.println(StringUtils.commify( new String[] {}));
        System.out.println(StringUtils.commify( new String[] {"a"}));
        System.out.println(StringUtils.commify( new String[] {"a", "b"}));
        System.out.println(StringUtils.commify( new String[] {"a", "b", "c"}));
    }
}
