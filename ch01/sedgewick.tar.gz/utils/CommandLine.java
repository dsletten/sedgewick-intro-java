/**
 * Started: Aug 7, 2010 12:32:09 AM
 */
package utils;

/**
 * Class summary.
 * Class description.
 *
 * @author dsletten
 * @version 1.0, Aug 7, 2010
 */
public class CommandLine {
	public static boolean checkArgs(String[] args, String... expected) {
		return args.length == expected.length;			
	}
	
	public static void printUsage(String className, String... expected) {
		System.err.println("Usage:");
		System.err.print("java " + className);

		for (String arg : expected) {
			System.err.print(" ");
			System.err.print("<" + arg + ">");
		}

		System.err.println();
	}
	
	public static boolean enforceArgs(String className, String[] args, String... expected) {
		if ( checkArgs(args, expected) ) {
			return true;
		} else {
			printUsage(className, expected);
			return false;
		}
	}
}
