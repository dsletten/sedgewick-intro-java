/**
 * Started: Jul 12, 2010 10:51:10 PM
 */
package utils;

/**
 * Class summary.
 * Class description.
 *
 * @author dsletten
 * @version 1.0, Jul 12, 2010
 */
public class StringUtils
{
    public static String pluralize( int n, String singular, String plural )
    {
        if (n == 1)
        {
            return singular;
        }
        else
        {
            return plural;
        }
    }

    public static String pluralize( int n, String singular )
    {
        return pluralize( n, singular, singular + "s" );
    }

    public static String pluralize( double d, String singular, String plural )
    {
        if (d == 1)
        {
            return singular;
        }
        else
        {
            return plural;
        }
    }

    public static String pluralize( double d, String singular )
    {
        return pluralize( d, singular, singular + "s" );
    }

    public static String commify( String[] elts )
    {
        if (elts.length == 0)
        {
            return "";
        }
        else if (elts.length == 1)
        {
            return elts[0];
        }
        else if (elts.length == 2)
        {
            return elts[0] + " and " + elts[1];
        }
        else
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < elts.length - 1; i++ )
            {
                sb.append( elts[i] );
                sb.append( ", " );
            }

            sb.append( "and " );
            sb.append( elts[elts.length-1] );

            return sb.toString();
        }
    }
}
